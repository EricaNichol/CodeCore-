$(document).on('ready', function() {

  // Your Code Here...

});
